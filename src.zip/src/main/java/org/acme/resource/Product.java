//vinyas.model.Product
package org.acme.resource;

import jakarta.persistence.*;
import lombok.Data;

import java.math.BigDecimal;


@Entity
@Data
public class Product {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(unique = true)
    private String code;

    private String description;

    private BigDecimal price;

    private int stock;

    @ManyToOne
    @JoinColumn(name = "id_brand_fk")
    private Brand brand;

//        @OneToMany(mappedBy = "product", cascade = CascadeType.ALL)
//        private List<Cart> carts;


}