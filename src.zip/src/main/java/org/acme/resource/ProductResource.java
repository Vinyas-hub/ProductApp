//ProductResource

package org.acme.resource;

import jakarta.annotation.security.RolesAllowed;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.enums.SecuritySchemeType;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.security.SecurityScheme;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

import java.util.List;
import java.util.stream.Collectors;
@SecurityScheme(
        scheme = "bearer",
        type = SecuritySchemeType.HTTP,
        bearerFormat = "JWT"
)
@Path("/products")
@Tag(name = "product resource", description = "Product APIs")
public class ProductResource {

    @Inject
    ProductRepository productRepository;

    @Inject
    BrandRepository brandRepository;

//    @Inject
//    CartRepository cartRepository;
//
//    @Inject
//    CartService cartService;

    @POST

    @RolesAllowed({"admin"})
    @Transactional
    @Operation(summary = "Create a new product")
    @APIResponse(responseCode = "200", description = "Product created successfully", content = @Content(mediaType = MediaType.APPLICATION_JSON, schema = @Schema(implementation = ProductResponseDTO.class)))
    @APIResponse(responseCode = "400", description = "Bad Request")
    @APIResponse(responseCode = "500", description = "Internal Server Error")
    public ProductResponseDTO persist(ProductDTO newProduct) {
        Product p = new Product();
        p.setId(newProduct.getId());
        p.setCode(newProduct.getCode());
        p.setDescription(newProduct.getDescription().toUpperCase());
        p.setStock(newProduct.getStock());
        p.setPrice(newProduct.getPrice());
        p.setBrand(brandRepository.findById(newProduct.getIdBrand()));
        productRepository.persist(p);

        return new ProductResponseDTO(p);
    }


    @PUT
    @Path("/{id}")
    @Transactional
    @Operation(summary = "update product")
    @APIResponse(responseCode = "200", description = "Product updated successfully", content = @Content(mediaType = MediaType.APPLICATION_JSON, schema = @Schema(implementation = ProductResponseDTO.class)))
    @APIResponse(responseCode = "400", description = "Bad Request")
    @APIResponse(responseCode = "500", description = "Internal Server Error")
    @RolesAllowed({"admin"})
    public ProductResponseDTO update(@PathParam("id") Long id, ProductDTO receiveProduct) {
        Product p = productRepository.findById(id);
        if (p != null) {
            p.setId(receiveProduct.getId());
            p.setCode(receiveProduct.getCode());
            p.setDescription(receiveProduct.getDescription().toUpperCase());
            p.setStock(receiveProduct.getStock());
            p.setPrice(receiveProduct.getPrice());
            p.setBrand(brandRepository.findById(receiveProduct.getIdBrand()));
            return new ProductResponseDTO(p);
        } else {
            // Handle case when product with given id is not found
            throw new NotFoundException("Product with ID " + id + " not found");
        }
    }
    @DELETE
    @Path("/delete/{id}")
    @Transactional
    @Operation(summary = "delete product by ID")
    @APIResponse(responseCode = "200", description = "Product deleted successfully", content = @Content(mediaType = MediaType.APPLICATION_JSON, schema = @Schema(implementation = ProductResponseDTO.class)))
    @APIResponse(responseCode = "400", description = "Bad Request")
    @APIResponse(responseCode = "500", description = "Internal Server Error")
    @RolesAllowed({"admin"})
    public String deleteById(@PathParam("id") Long id) {
       // System.out.println("Attempting to delete product with ID: " + id);
        boolean deleted = productRepository.deleteById(id);
        return deleted ? "Deleted with success" : "Not found";
    }


    @GET
    @Operation(summary = "get all product")
    @APIResponse(responseCode = "200", description = "All Product fetched successfully", content = @Content(mediaType = MediaType.APPLICATION_JSON, schema = @Schema(implementation = ProductResponseDTO.class)))
    @APIResponse(responseCode = "400", description = "Bad Request")
    @APIResponse(responseCode = "500", description = "Internal Server Error")
    @RolesAllowed({"admin"})
    public List<ProductResponseDTO> listAll() {
        List<ProductResponseDTO> list = productRepository.listAllOrdered().stream().map(product -> new ProductResponseDTO(product)).collect(Collectors.toList());
        return list;
    }

    @GET
    @Path("/{id}")
    @Operation(summary = "get product by ID")
    @APIResponse(responseCode = "200", description = "Product fetched successfully", content = @Content(mediaType = MediaType.APPLICATION_JSON, schema = @Schema(implementation = ProductResponseDTO.class)))
    @APIResponse(responseCode = "400", description = "Bad Request")
    @APIResponse(responseCode = "500", description = "Internal Server Error")
    @RolesAllowed({"admin"})
    public ProductResponseDTO findById(@PathParam("id") Long id) {
        ProductResponseDTO entity = new ProductResponseDTO(productRepository.findById(id));
        return entity;
    }



}
