//ProductRepository
package org.acme.resource;

import io.quarkus.hibernate.orm.panache.PanacheRepository;
import jakarta.enterprise.context.ApplicationScoped;

import java.util.List;

@ApplicationScoped
public class ProductRepository implements PanacheRepository<Product> {

    public List<Product> listAllOrdered() {
        List<Product> list = find("order by id").list();
        return list;
    }

    public List<Product> findByDescription(String description) {
        String like = "%" + description + "%";
        return find("description like ?1", like).list();
    }
}