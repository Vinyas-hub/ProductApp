package org.acme.resource;

//ProductResponseDTO

import lombok.Getter;

import java.math.BigDecimal;


@Getter
public class ProductResponseDTO {

    private  Long id;
    private String code;
    private String description;
    private BigDecimal price;
    private int stock;
    private String brand;

    public ProductResponseDTO() {
    }

    public ProductResponseDTO(Product p) {
        this.id=p.getId();
        this.code = p.getCode();
        this.description = p.getDescription();
        this.price = p.getPrice();
        this.stock = p.getStock();
        this.brand = p.getBrand().getName();
    }
}