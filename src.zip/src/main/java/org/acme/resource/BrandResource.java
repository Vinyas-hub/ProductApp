//package dev.vinyas.resource;
//
//import java.util.List;
//
//import io.swagger.v3.oas.annotations.Parameter;
//import io.swagger.v3.oas.annotations.media.Content;
//import io.swagger.v3.oas.annotations.media.Schema;
//import io.swagger.v3.oas.annotations.responses.ApiResponse;
//import io.swagger.v3.oas.annotations.tags.Tag;
//import jakarta.inject.Inject;
//import jakarta.transaction.Transactional;
//import jakarta.ws.rs.*;
//
//
//import dev.vinyas.model.Brand;
//import dev.vinyas.repository.BrandRepository;
//import jakarta.ws.rs.core.MediaType;
//import org.eclipse.microprofile.openapi.annotations.Operation;
//
//@Path("/brands")
//@Tag(name="brand resource",description = "Brand APIs")
//public class BrandResource {
//
//    @Inject
//    BrandRepository brandRepository;
//
//    @POST
//    @Transactional
//    @Operation(summary = "Create a new brand")
//    @ApiResponse(responseCode = "200",
//            description = "brand created",
//            content = @Content(mediaType = MediaType.APPLICATION_JSON, schema = @Schema(implementation = Brand.class)))
//    @ApiResponse(responseCode = "400", description = "Bad Request")
//    @ApiResponse(responseCode = "500", description = "Internal Server Error")
//    public Brand persist(Brand newBrand) {
//        Brand m = new Brand();
//        m.setName(newBrand.getName().toUpperCase());
//        brandRepository.persist(m);
//        return m;
//    }
//
//    @PUT
//    @Path("/{id}")
//    @Transactional
//    @Operation(summary = "Update a brand by ID")
//    @ApiResponse(responseCode = "200",description = "success", content = @Content(mediaType = MediaType.APPLICATION_JSON, schema = @Schema(implementation = Brand.class)))
//    @ApiResponse(responseCode = "400", description = "Bad Request")
//    @ApiResponse(responseCode = "500", description = "Internal Server Error")
//    public Brand update(
//            @PathParam("id") @Parameter(description = "Brand ID") Long id,
//            Brand receivedBrand
//    ) {
//        if (brandRepository.findByIdOptional(id).isPresent()) {
//            Brand m = brandRepository.findById(id);
//            m.setName(receivedBrand.getName().toUpperCase());
//            brandRepository.persist(m);
//            return m;
//        } else {
//            return null;
//        }
//    }
//
//    @DELETE
//    @Path("/{id}")
//    @Transactional
//    @Operation(summary = "Delete a brand by ID")
//    @ApiResponse(responseCode = "200", description = "success",content = @Content(mediaType = MediaType.APPLICATION_JSON, schema = @Schema(implementation = String.class)))
//    @ApiResponse(responseCode = "400", description = "Bad Request")
//    @ApiResponse(responseCode = "500", description = "Internal Server Error")
//    public String deleteBrand(@PathParam("id") @Parameter(description = "Brand ID") Long id) {
//        System.out.println("Attempting to delete brand with ID: " + id);
//        boolean deleted = brandRepository.deleteById(id);
//        return deleted ? "Deleted with success" : "Not found";
//    }
//
//    @GET
//    @Operation(summary = "List all brands")
//    @ApiResponse(responseCode = "200",description = "success", content = @Content(mediaType = MediaType.APPLICATION_JSON, schema = @Schema(implementation = Brand.class, type = "array")))
//    @ApiResponse(responseCode = "400", description = "Bad Request")
//    @ApiResponse(responseCode = "500", description = "Internal Server Error")
//    public List<Brand> listAll() {
//        List<Brand> list = brandRepository.findAll().list();
//        return list;
//    }
//
//    @GET
//    @Path("/{id}")
//    @Operation(summary = "Get a brand by ID")
//    @ApiResponse(responseCode = "200",description = "success", content = @Content(mediaType = MediaType.APPLICATION_JSON, schema = @Schema(implementation = Brand.class)))
//    @ApiResponse(responseCode = "400", description = "Bad Request")
//    @ApiResponse(responseCode = "500", description = "Internal Server Error")
//    public Brand getBrandById(@PathParam("id") @Parameter(description = "Brand ID") Long id) {
//        return brandRepository.findByIdOptional(id).orElse(null);
//    }
//}
package org.acme.resource;

import jakarta.annotation.security.RolesAllowed;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.enums.SchemaType;
import org.eclipse.microprofile.openapi.annotations.enums.SecuritySchemeType;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.parameters.Parameter;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponses;
import org.eclipse.microprofile.openapi.annotations.security.SecurityScheme;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

import java.util.List;

@Path("/brands")
@Tag(name="brand resource",description = "Brand APIs")
@SecurityScheme(
        scheme = "bearer",
        type = SecuritySchemeType.HTTP,
        bearerFormat = "JWT"
)
public class BrandResource {

    @Inject
    BrandRepository brandRepository;

    @POST
    @Transactional
    @Operation(summary = "Create a new brand")
    @APIResponses(value = {
            @APIResponse(responseCode = "200", description = "brand created successfully", content = @Content(mediaType = MediaType.APPLICATION_JSON, schema = @Schema(implementation = Brand.class, type = SchemaType.STRING))),
            @APIResponse(responseCode = "400", description = "Bad Request"),
            @APIResponse(responseCode = "500", description = "Internal Server Error")
    })
    @RolesAllowed({"admin"})
    public Brand persist(Brand newBrand) {
        Brand m = new Brand();
        m.setName(newBrand.getName().toUpperCase());
        brandRepository.persist(m);
        return m;
    }

    @PUT
    @Path("/{id}")
    @Transactional
    @Operation(summary = "Update a brand by ID")
    @APIResponses(value = {
            @APIResponse(responseCode = "200", description = "brand updated successfully", content = @Content(mediaType = MediaType.APPLICATION_JSON, schema = @Schema(implementation = Brand.class, type = SchemaType.STRING))),
            @APIResponse(responseCode = "400", description = "Bad Request"),
            @APIResponse(responseCode = "500", description = "Internal Server Error")
    })
    @RolesAllowed({"admin"})
    public Brand update(
            @PathParam("id") @Parameter(description = "Brand ID") Long id,
            Brand receivedBrand
    ) {
        if (brandRepository.findByIdOptional(id).isPresent()) {
            Brand m = brandRepository.findById(id);
            m.setName(receivedBrand.getName().toUpperCase());
            brandRepository.persist(m);
            return m;
        } else {
            return null;
        }
    }

    @DELETE
    @Path("/{id}")
    @Transactional
    @Operation(summary = "Delete a brand by ID")
    @APIResponses(value = {
            @APIResponse(responseCode = "200", description = "brand deleted successfully", content = @Content(mediaType = MediaType.APPLICATION_JSON, schema = @Schema(implementation = Brand.class, type = SchemaType.STRING))),
            @APIResponse(responseCode = "400", description = "Bad Request"),
            @APIResponse(responseCode = "500", description = "Internal Server Error")
    })
    @RolesAllowed({"admin"})
    public String deleteBrand(@PathParam("id") @Parameter(description = "Brand ID") Long id) {
        System.out.println("Attempting to delete brand with ID: " + id);
        boolean deleted = brandRepository.deleteById(id);
        return deleted ? "Deleted with success" : "Not found";
    }

    @GET
    @Operation(summary = "List all brands")
    @APIResponses(value = {
            @APIResponse(responseCode = "200", description = "brand fetched  successfully", content = @Content(mediaType = MediaType.APPLICATION_JSON, schema = @Schema(implementation = Brand.class,type = SchemaType.STRING))),
            @APIResponse(responseCode = "400", description = "Bad Request"),
            @APIResponse(responseCode = "500", description = "Internal Server Error")
    })
    @RolesAllowed({"customer","admin"})
    public List<Brand> listAll() {
        List<Brand> list = brandRepository.findAll().list();
        return list;
    }

    @GET
    @Path("/{id}")
    @Operation(summary = "Get a brand by ID")
    @APIResponses(value = {
            @APIResponse(responseCode = "200", description = "brand fetched by Id successfully", content = @Content(mediaType = MediaType.APPLICATION_JSON, schema = @Schema(implementation = Brand.class, type = SchemaType.STRING))),
            @APIResponse(responseCode = "400", description = "Bad Request"),
            @APIResponse(responseCode = "500", description = "Internal Server Error")
    })
    @RolesAllowed({"customer","admin"})
    public Brand getBrandById(@PathParam("id") @Parameter(description = "Brand ID") Long id) {
        return brandRepository.findByIdOptional(id).orElse(null);
    }
}
