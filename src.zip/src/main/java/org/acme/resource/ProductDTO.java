//ProductDTO
package org.acme.resource;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Getter;

import java.math.BigDecimal;


@Getter
public class ProductDTO {
    private Long id;
    @NotBlank(message = "Product code is required")
    @Size(min = 3, max = 5, message = "Product code must be between 3 and 5 characters")
    private String code;
    @NotBlank(message = "Description is required")
    @Size(min = 3, message = "Description must be at least 3 characters")
    private String description;
    @NotNull(message = "Price is required")
    @Min(value = 0, message = "Price must be greater than or equal to 0")
    private BigDecimal price;
    @NotNull(message = "Stock is required")
    @Min(value = 0, message = "Stock must be greater than or equal to 0")
    private int stock;
    @NotNull(message = "Brand ID is required")
    private Long idBrand;
}